const db = require("./banco")

const Agendamentos = db.sequelize.define('agendamentos',{
    nome:{
        type: db.Sequelize.STRING
    },
    telefone:{
        type: db.Sequelize.STRING
    },
    origem:{
        type: db.Sequelize.STRING
    },
    data_contato:{
        type: db.Sequelize.DATEONLY
    },
    observacao:{
        type: db.Sequelize.TEXT
    }
})

// Função para criar um novo agendamento
const criarAgendamento = async (dadosAgendamento) => {
    try {
        const novoAgendamento = await Agendamentos.create(dadosAgendamento);
        return novoAgendamento;
    } catch (error) {
        throw error;
    }
};

// Função para listar todos os agendamentos
const listarAgendamentos = async () => {
    try {
        const agendamentos = await Agendamentos.findAll();
        return agendamentos;
    } catch (error) {
        throw error;
    }
};

// Função para atualizar um agendamento
const atualizarAgendamento = async (id, novosDados) => {
    try {
        await Agendamentos.update(novosDados, {
            where: { id: id }
        });
        return true;
    } catch (error) {
        throw error;
    }
};

// Função para deletar um agendamento
const deletarAgendamento = async (id) => {
    try {
        await Agendamentos.destroy({
            where: { id: id }
        });
        return true;
    } catch (error) {
        throw error;
    }
};

module.exports = {
    Agendamentos: Agendamentos,
    criarAgendamento: criarAgendamento,
    listarAgendamentos: listarAgendamentos,
    atualizarAgendamento: atualizarAgendamento,
    deletarAgendamento: deletarAgendamento
};


